% Programme d'initialisation du modele SATELLITE_ORBITE.mdl, iniSATELLITE.m
%
% Jean de Lafontaine
% Cr�ation: janvier 2003
% R�vision: novembre 2011
% R�vision: septembre 2014

  clc
  clear all
  close all
 % close_system('SATELLITE_ORBITE', 0)
  
% Ex�cution des fichiers sous-systemes
% ------------------------------------

  CONSTANTS; 
  TERRE;
  SOLEIL;
  STATION;
  DYNORB;


