% Fichier d'initialisation de la dynamique en rotation du satellite

% JdeL 
% D�cembre 2011

% ROUE 1
% ------

% Inertie et conditions initiales de la roue 1

 

% ROUE 2
% ------

% Inertie et conditions initiales de la roue 2



% ROUE 3
% ------

% Inertie et conditions initiales de la roue 3



% SATELLITE
% ---------

% Inertie et conditions initiales du satellite


 

